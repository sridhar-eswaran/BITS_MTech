from tkinter import Tk,filedialog,simpledialog
gui = Tk()
gui.withdraw()

# function to read input file and store each line as list
def readServerTransaction(filepath): #function initialization
    with open(filepath) as file:   # open file handler
        lines = file.readlines()  #read each line and store them in list
    lines = [line.replace('\n','').split(',') for line in lines] # remove line breaks and split list based on comma
    return lines

def getNodeList(input): # function to extract the node list
    nodes = input[2]+input[3] # extract 1st and 2nd line
    for node in range(3,len(input)): # from third line, keep appending list elements
        nodes = nodes+input[node]
    nodes = ''.join(nodes) # join the list
    nodes = ''.join(filter(lambda x: not x.isdigit(), nodes)) # remove the edge values
    nodes = list(set(nodes.replace(" ",""))) #remvoe spaces and duplicates
    return nodes # unique nodes

def getEdgeList(input): # function to get the edge values into dict
    edges = {} # initilaization
    for node in range(2,len(input)): # for loop for the all the transactiosn
        edge = input[node][0].split(' ') #split list based on whitespace character
        edges[(edge[0],edge[1])]=int(edge[2]) # assign key and values to dict
    return edges # return dict

# function to find the shortest path using Dijkstra's algo
def dijktras(nodes,edges,source_node): # functional initialization
    path_len = {v:float('inf') for v in nodes} # set path lengths to infinite
    path_len[source_node] = 0 # set the path length for the source index to zero
    adjacent_nodes = {v:{} for v in nodes}  # initialize adjacent node dict - node names as keys
    for (u,v), w_uv in edges.items(): # for loop to assign edge values to adjacent node dict values
        adjacent_nodes[u][v] = w_uv
    temp_node = [node for node in nodes] # temporary list for check visited nodes
    while len(temp_node) > 0: # while loop until unvisited node becomes zero
        upper = {node: path_len[node] for node in temp_node} # path len dict replaces the inf in the pathlen dict
        u = min(upper,key=upper.get) # find the smallest edge and get the node
        temp_node.remove(u) # remove the smallest in the temp node as we have visited it
        for node,w_uv in adjacent_nodes[u].items(): # for loop for calculate the min path for adjacent node
            path_len[node] = min(path_len[node],path_len[u]+w_uv) # get the min of path len and store it for the node
    return path_len #return shortest path dict

#Get user input for files
inputTxtFileLocation = filedialog.askopenfile(title='Choose Input PS6 file') # ask user for the input file
# source_node = simpledialog.askstring('Input','Enter source node') # ask user to input the source node

#read the file selected by user
input = readServerTransaction(inputTxtFileLocation.name) # read the file selected by the user

# read info from the file selected
source_node = input[1][0][-1] # read the second line, last character for source node
nodes = getNodeList(input) # get node names for the given input
edges = getEdgeList(input) # get transactions in dict for passing to algo

# get the shortest path
path_lengths = dijktras(nodes,edges,source_node) # apply algo on the given nodes, edges and from the source node from the input file

# format and print the output
path_lengths = {key: value for key, value in sorted(path_lengths.items())} # sort the dict based on key in alphabetic order
path_lengths.pop(source_node) # remove source node as the value will be zero
filename = inputTxtFileLocation.name.split('/')[0:-1] # get the location of the input file
filename = '/'.join(filename)+'/outputPS6.txt' # create a full file name to create output file in the same location as input
with open(filename, 'w+') as file: # file handling - create in write mode
    for key, value in path_lengths.items(): # call items from the dict
        file.write(str(key)+' '+str(value)+'\n') # write them into the output file matching the given output format
